/**
 * @file course.c
 * @author Stella Gu
 * @brief Functions to manage courses
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * @brief Adds a student to a course
 * 
 * @param course the pointer to a course a student will be enrolled in
 * @param student a student to be enrolled in a course
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  //Checks if it is the first student to add to a course
  //Uses calloc if it is the first student, otherwise realloc to add more space to the array
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Prints the course's name, code, total number of students, and the students taking the course
 * 
 * @param course the pointer to a course which will be printed
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Returns the student with the highest average in a course
 * 
 * @param course the pointer to a course to find the top student in
 * @return the student with the highest average in the course
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
  
  //Saves the student with the highest average of the course to the student variable
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief Returns an array with all the passing students 
 * 
 * @param course the pointer to a course where passing students will be found
 * @param total_passing the number of students with
 * @return the array of students who are passing the course 
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  //Counts the number of passing students
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  //Adds all the passing students to an array
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}