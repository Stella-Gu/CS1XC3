/**
 * @file course.h
 * @author Stella Gu
 * @brief The course structure and course related function initializations
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>

/**
 * @brief course type stores a course with fields name, code, students, total students. 
 * 
 */
typedef struct _course 
{
  char name[100]; /**< the course's name */ 
  char code[10]; /**< the course's code */
  Student *students; /**< the course's students */
  int total_students; /**< the course's total students */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


