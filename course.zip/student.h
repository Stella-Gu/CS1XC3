/**
 * @file student.h
 * @author Stella Gu
 * @brief The student structure and student related function initializations
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief student type stores a student with fields first name, last name, id, grades, number of grades. 
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; /**< the student's first name */
  char last_name[50]; /**< the student's last name */
  char id[11]; /**< the student's id */
  double *grades; /**< the student's grades */
  int num_grades; /**< the student's number of grades */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
